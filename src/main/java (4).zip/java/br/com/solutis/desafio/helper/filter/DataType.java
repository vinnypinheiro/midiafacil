package br.com.solutis.desafio.helper.filter;

public enum DataType {
    ENUM, NUMBER, STRING, INTEGER, BEAN, DATETIME, BOOLEAN, DOUBLE, LONG, DATE
}
