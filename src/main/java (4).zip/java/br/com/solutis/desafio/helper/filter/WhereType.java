package br.com.solutis.desafio.helper.filter;

public enum WhereType {
    AND, OR
}
