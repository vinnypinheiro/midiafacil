package br.com.solutis.desafio.security;

public enum ProfileEnum {
	ROLE_ADMIN,
	ROLE_CUSTOMER,
	ROLE_TECHNICIAN
}
