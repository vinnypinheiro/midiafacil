package br.com.solutis.desafio.service;
import br.com.solutis.desafio.domain.Agencia;
import br.com.solutis.desafio.helper.filter.FilterData;
import br.com.solutis.desafio.helper.filter.WhereClause;
import br.com.solutis.desafio.repository.AgenciaRepository;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

import static org.hibernate.criterion.Restrictions.ilike;

/**
 * Created by fabricio on 02/09/18.
 */

@Service("AgenciaService")
public class AgenciaService {

    @PersistenceContext
    private EntityManager em;

    @Autowired
    AgenciaRepository agenciaRepository;

    public Agencia save(Agencia bean){
        return agenciaRepository.save(bean);
    }

    public Agencia getById(Long id){
        return agenciaRepository.getOne(id);
    }

    public void delete(Long id){
        agenciaRepository.deleteById(id);
    }

    public Page<Agencia> getList(Integer pageNumber) {
        PageRequest pageRequest = new PageRequest(pageNumber - 1, 20, Sort.Direction.ASC, "id");
        return agenciaRepository.findAll(pageRequest);
    }


    public List<Agencia> select(final FilterData filter) {
        Criteria crit = em.unwrap(Session.class).createCriteria(Agencia.class);
        for(WhereClause wc :filter.getWhereClauses()) {
            //crit.add(Restrictions.ilike(wc.getName(), wc.getIniValue()));
        }
        List<Agencia> lista = crit.list();

        return lista;
    }

}
