package br.com.solutis.desafio.service;


import org.springframework.stereotype.Service;

@Service
public class ReportService {



}
