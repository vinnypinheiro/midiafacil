package br.com.solutis.desafio.domain;

import java.io.Serializable;



public class DomainBase<Long extends Serializable> implements Serializable {
}
