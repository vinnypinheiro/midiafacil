import {DomainBase} from '../../utils/utils'; 

export interface FaturamentoPadrao extends DomainBase { 

     descricao: string; 
     texto: string; 
}