import {DomainBase} from '../../utils/utils'; 

export interface Uf extends DomainBase { 

     nome: string; 
     pais_id_id :  number; 
     pais_id_nome :  string; 
     pais_id_codigo :  string; 
}