import {DomainBase} from '../../utils/utils'; 

export interface Pais extends DomainBase { 

     nome: string; 
     sigla: string; 
}