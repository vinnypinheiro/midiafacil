import {DomainBase} from '../../utils/utils'; 

export interface TipoMidia extends DomainBase { 

     nome: string;

}