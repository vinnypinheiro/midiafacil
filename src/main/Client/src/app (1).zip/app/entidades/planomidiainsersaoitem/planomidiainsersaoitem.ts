import {DomainBase} from '../../utils/utils'; 

export interface PlanoMidiaInsersaoItem extends DomainBase { 

}