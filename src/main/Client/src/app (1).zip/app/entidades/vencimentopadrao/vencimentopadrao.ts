import {DomainBase} from '../../utils/utils'; 

export interface VencimentoPadrao extends DomainBase { 

     descricao: string; 
     texto: string; 
}