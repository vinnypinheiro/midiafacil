import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanomidiaViewComponent } from './planomidia-view.component';

describe('PlanomidiaViewComponent', () => {
  let component: PlanomidiaViewComponent;
  let fixture: ComponentFixture<PlanomidiaViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanomidiaViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanomidiaViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
