import {DomainBase} from '../../utils/utils'; 

export interface TipoProduto extends DomainBase { 

     nome: string; 
}