import {DomainBase} from '../../utils/utils'; 

export interface Formato extends DomainBase { 

     nome: string;

}