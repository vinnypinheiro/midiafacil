import {DomainBase} from '../../utils/utils'; 

export interface PlanoMidiaInsersao extends DomainBase { 

}