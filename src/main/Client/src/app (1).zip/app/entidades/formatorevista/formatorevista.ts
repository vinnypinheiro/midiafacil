import {DomainBase} from '../../utils/utils'; 

export interface FormatoRevista extends DomainBase { 

     nome: string; 
}