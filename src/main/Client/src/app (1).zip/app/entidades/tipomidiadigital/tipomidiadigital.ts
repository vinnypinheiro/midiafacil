import {DomainBase} from '../../utils/utils'; 

export interface TipoMidiaDigital extends DomainBase { 

     nome: string; 
}